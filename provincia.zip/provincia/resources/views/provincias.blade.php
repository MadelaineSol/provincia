<!DOCTYPE html>
<html>
<head>
    <title>Cargar Provincia</title>
    <!-- Enlazar los estilos CSS (por ejemplo, Bootstrap) si es necesario -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <h2>Cargar Nueva Provincia</h2>
        <form method="POST" action="{{ route('guardar-provincia') }}">
       
            @csrf
            <div class="form-group">
                <label for="detalle">Detalle de la provincia:</label>
                <input type="text" class="form-control" id="detalle" name="detalle" placeholder="Ingrese el detalle">
            </div>
            <button type="submit" class="btn btn-primary">Guardar</button>
        </form>
    </div>

    <!-- Enlazar los scripts JavaScript si es necesario -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
