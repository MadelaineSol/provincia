<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Provincia; // Aquí se importa el modelo Provincia

class ProvinciaController extends Controller
{
    public function guardarProvincia(Request $request)
    {
        // Validar los datos recibidos desde el formulario
        $request->validate([
            'detalle' => 'required|max:100', // Asegúrate de que el detalle sea obligatorio y tenga máximo 100 caracteres
        ]);

        // Crear una nueva instancia de Provincia y guardarla en la base de datos
        $provincia = Provincia::create([
            'detalle' => $request->detalle,
        ]);

        // Puedes realizar otras acciones o retornar una respuesta según necesites
        return redirect()->back()->with('success', 'Provincia creada con éxito');
    }
}
